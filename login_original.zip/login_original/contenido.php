<?php session_start();



if (isset($_SESSION['usuario'])) {
	require 'views/contenido.view.php';
} else {
	header('Location: login.php');
}


/**
 * Created by PhpStorm.
 * User: NAYELLI GONZALEZ
 * Date: 11/07/18
 * Time: 18:20
 */


?>