<?php
/**
 * Created by PhpStorm.
 * User: NAYELLI GONZALEZ
 * Date: 16/07/18
 * Time: 18:56
 */

$username="root";
$password="";
$database="login_practica";

?>